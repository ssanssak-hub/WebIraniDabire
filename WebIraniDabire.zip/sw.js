/* آفلاین‌سازی: فایل‌های برنامه + همه‌ی فونت‌های fonts/fonts.json کش می‌شوند. اول شبکه، بعد کش. */
const C = 'pfk-AUTO_VERSION'; // ⬅️ این خط توسط گیت‌هاب به صورت خودکار تغییر می‌کند. دست نزنید!
const FILES = [
  "./",
  "index.html",
  "scripts.html",
  "keyboard.html",
  "templates.html",
  "samples.html",
  "about.html",
  "privacy-policy.html",
  "delete-account.html",
  "manifest.json",
  "css/style.css",
  "css/site.css",
  "icons/icon-192.png",
  "icons/icon-512.png",
  "fonts/fonts.json",
  "samples/sample-text.png",
  "samples/sample-on-image.png",
  "js/custom-keyboard-view",
  "js/export-utils",
  "js/font-manager",
  "js/font-name-reader",
  "js/font-unicode-reader",
  "js/image-text-editor",
  "js/main",
  "js/saved-files",
  "js/site",
  "js/theme-manager",
  "js/unicode-scripts",
  "js/utils"
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(C).then(async c => {
      await c.addAll(FILES);
      try {
        const a = await (await fetch('fonts/fonts.json')).json();
        await c.addAll(a.map(f => 'fonts/' + encodeURIComponent(f)));
      } catch (x) {}
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(k => 
      Promise.all(k.filter(x => x !== C).map(x => caches.delete(x)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  
  e.respondWith(
    fetch(e.request).then(r => {
      const cp = r.clone();
      caches.open(C).then(c => c.put(e.request, cp));
      return r;
    }).catch(() => 
      caches.match(e.request,{ignoreSearch:true}).then(m => m || caches.match('index.html'))
    )
  );
});
